MITTI KISAN — Android/Termux starter PWA
=========================================

Features in this starter:
- High-contrast Mitti Clay UI and responsive home screen
- Six feature screens: Fasal Doctor, Mandi Bhav, Mausam & Pani, Sarkari Sahayata, Kisan Chaupal, Seedha Bazaar
- Hindi speech-to-text where browser supports it; Hindi text-to-speech where supported
- Service-worker cache for app-shell offline opening
- Demo mandi prices are clearly labelled as NOT live data
- Disease advice is only preliminary and avoids claiming AI diagnosis
- Scheme info is general and asks user to verify current eligibility

Run on a computer:
1. Extract this ZIP.
2. In the folder, run: python -m http.server 8080
3. Open http://localhost:8080 in a browser.
   (PWA/service worker normally needs localhost or HTTPS.)

Run on Android using Termux:
1. Install Termux from a trusted official source.
2. Copy/extract this folder into Termux storage, or use:
   termux-setup-storage
3. cd into the extracted MittiKisan folder.
4. Run: pkg update
5. Run: pkg install python
6. Run: python -m http.server 8080
7. On the same phone open: http://127.0.0.1:8080

Important limitations:
- This is a working front-end prototype, not a production super-app.
- Login, cloud database, real-time mandi API, real weather API, AI model, verified buyer accounts,
  farmer-to-farmer posting, government portal integration and secure phone authentication are not connected.
- Do not rely on sample prices or preliminary symptom text for financial or crop-protection decisions.
- For public deployment, host over HTTPS and configure backend/authentication and privacy/security.
